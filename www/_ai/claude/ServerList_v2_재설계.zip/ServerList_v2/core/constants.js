/**
 * ====================================================================
 *  [상태] 상수/DOM id — constants.js
 * --------------------------------------------------------------------
 *  역할   : 버전 임계값, DOM id, 서버 필드명, 사운드 코드 등 매직값 모음
 *  시점   : 필요 모듈에서 require
 *  입출력 : 출력: 상수 맵
 *  구대응 : ServerList.js L152~156 (SAPGUIVER/POPID/SERVER_TBL_ID/BINDROOT)
 *  의존   : 없음
 * ====================================================================
 */
"use strict";

module.exports = {
    SAPGUI_MIN_VER: 7700,
    DOM: {
        APP: "app", BUSY: "u4aWsBusyIndicator", AUDIO: "u4aWsAudio",
        TREE: "ws-tree", SERVER_TABLE: "ws-server-table", EDIT_DIALOG: "ws-edit-dialog",
    },
    FIELD: { UUID: "uuid", NAME: "name", SID: "systemid", HOST: "host", SNO: "insno", SAVED: "ISSAVE", SETTINGS: "settings" },
    SOUND: { ACTIVE: "01", ERROR: "02" },
};
