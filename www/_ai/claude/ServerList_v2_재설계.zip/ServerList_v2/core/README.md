# core — 상태(데이터) 핵심

UI 프레임워크 비종속. 구 단일 JSONModel을 평범한 객체 + 구독으로 대체.

| 파일 | 역할 | 구 대응 |
|------|------|---------|
| `state.js` | 상태 단일 출처(4경로) | JSONModel `/WSLANGU /SAPLogon /ServerList /SAPLogonItems` |
| `store.js` | 변경→부분 렌더 트리거 | `model.refresh` / 바인딩 |
| `constants.js` | 상수/DOM id | L152~156 |

> "상태 바꾸기 = `store.set(key, value)` → 구독한 뷰가 다시 그림" 한 가지 규칙만 기억.
