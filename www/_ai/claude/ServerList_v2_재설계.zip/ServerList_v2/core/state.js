/**
 * ====================================================================
 *  [상태] 상태 객체 — state.js
 * --------------------------------------------------------------------
 *  역할   : 구 단일 JSONModel 4경로 + UI 부가상태를 보관하는 단일 출처
 *  시점   : 모듈 로드 시 1회 생성, 앱 전역에서 공유
 *  입출력 : 출력: STATE 객체
 *  구대응 : JSONModel /WSLANGU /SAPLogon /ServerList /SAPLogonItems
 *  의존   : 없음(순수 데이터)
 * ====================================================================
 */
"use strict";

const STATE = {
    WSLANGU: {},        // 다국어 텍스트            (구 /WSLANGU)
    SAPLogon: {},       // 좌측 트리(가상루트+Node)  (구 /SAPLogon)
    ServerList: [],     // 전체 서버 원본            (구 /ServerList)
    SAPLogonItems: [],  // 선택노드의 우측 표시목록  (구 /SAPLogonItems)

    selectedNodeUuid: null,
    selectedServerUuid: null,
    sort: { key: null, dir: null },
};
module.exports = STATE;
