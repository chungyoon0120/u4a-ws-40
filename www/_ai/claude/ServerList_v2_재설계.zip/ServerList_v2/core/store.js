/**
 * ====================================================================
 *  [상태] 구독/렌더 트리거 — store.js
 * --------------------------------------------------------------------
 *  역할   : 상태 변경 시 해당 key 구독자에게만 알려 부분 재렌더 (구 model.refresh 대체)
 *  시점   : 뷰가 mount 시 subscribe, 핸들러가 set 호출
 *  입출력 : 입력: set(key,value) / 출력: 구독 콜백 실행
 *  구대응 : sap.ui.model JSONModel 양방향 바인딩
 *  의존   : ./state
 * ====================================================================
 */
"use strict";

const STATE = require("./state");
const subscribers = {}; // { key: Set<fn> }

function subscribe(key, fn) {
    (subscribers[key] = subscribers[key] || new Set()).add(fn);
    return () => subscribers[key].delete(fn);
}
function set(key, value) { STATE[key] = value; emit(key); }
function emit(key) { (subscribers[key] || []).forEach((fn) => fn(STATE[key], STATE)); }

module.exports = { STATE, subscribe, set, emit };
