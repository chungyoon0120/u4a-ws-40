# widgets — 재사용 공통 UI (기능 무관)

특정 화면에 묶이지 않는 범용 위젯. 여러 feature 가 가져다 쓴다.

| 파일 | 역할 | 구 대응 |
|------|------|---------|
| `modal.js` | 모달 베이스(백드롭/ESC/포커스) | `sap.m.Dialog` 공통 |
| `confirmDialog.js` | 정보/경고/확인 메시지 | `fnShowMessageBox` (L5239) |
| `toast.js` | 하단 토스트 | `sap.m.MessageToast` |
| `busyIndicator.js` | 전체 Busy 잠금 | `setBusy`(L215)/`setBusyIndicator`(L43) |
