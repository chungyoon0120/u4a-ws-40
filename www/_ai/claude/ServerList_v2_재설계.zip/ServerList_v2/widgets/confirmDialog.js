/**
 * ====================================================================
 *  [위젯] 확인/경고 — confirmDialog.js
 * --------------------------------------------------------------------
 *  역할   : 정보/경고/오류/확인(OK·Cancel) 메시지
 *  시점   : 삭제 확인, 오류 안내 등
 *  입출력 : 입력: (type,msg,onResult) / 출력: 모달
 *  구대응 : fnShowMessageBox(L5239)
 *  의존   : ./modal
 * ====================================================================
 */
"use strict";

const modal = require("./modal");
function show(type, msg, onResult) { /* TODO: I/W/E/S/C */ }
module.exports = { show };
