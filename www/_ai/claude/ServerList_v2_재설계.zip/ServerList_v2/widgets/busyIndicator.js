/**
 * ====================================================================
 *  [위젯] Busy — busyIndicator.js
 * --------------------------------------------------------------------
 *  역할   : 전체 화면 잠금 + 스피너 표시/해제
 *  시점   : 부팅·저장 등 비동기 시
 *  입출력 : 입력: 없음 / 출력: #u4aWsBusyIndicator 토글
 *  구대응 : setBusy(L215)/setBusyIndicator(L43)
 *  의존   : core/constants(DOM.BUSY), styles/busy.css
 * ====================================================================
 */
"use strict";

const { DOM } = require("../core/constants");

function _el() { return document.getElementById(DOM.BUSY); }

function show() {
    const el = _el();
    if (el) el.classList.add("is-visible");
    document.body.style.pointerEvents = "none";
}
function hide() {
    const el = _el();
    if (el) el.classList.remove("is-visible");
    document.body.style.pointerEvents = "";
}
module.exports = { show, hide };
