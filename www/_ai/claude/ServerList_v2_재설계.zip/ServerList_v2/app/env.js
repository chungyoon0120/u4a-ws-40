/**
 * ====================================================================
 *  [조립] 네이티브 핸들 집약 — env.js
 * --------------------------------------------------------------------
 *  역할   : REMOTE/FS/PATH/REGEDIT/XMLJS 등 네이티브 핸들을 한 곳에서 require 후 재노출
 *  시점   : 다른 모듈이 처음 require 할 때 1회 초기화
 *  입출력 : 출력: 공유 핸들 + runtime(전역설정) + setGlobalSettings()
 *  구대응 : ServerList.js 전역 require 영역(L115~186)
 *  의존   : @electron/remote, regedit, xml-js, random-key, 외부 pathInfo/WSUTIL/SETTINGS
 * ====================================================================
 */
"use strict";

const REMOTE = require("@electron/remote");
const CURRWIN = REMOTE.getCurrentWindow();
const PATH = REMOTE.require("path");
const APP = REMOTE.app;
const FS = REMOTE.require("fs");
const REGEDIT = require("regedit");
const XMLJS = require("xml-js");
const RANDOM = require("random-key");
const IPCRENDERER = require("electron").ipcRenderer;
const { spawn, exec } = require("child_process");

const APPPATH = APP.getAppPath();
const USERDATA = APP.getPath("userData");

const PATHINFO = require(PATH.join(APPPATH, "ws30", "resources", "pathInfo.js"));
const WSUTIL = require(PATHINFO.WSUTIL);
const SETTINGS = require(PATHINFO.WSSETTINGS);

REGEDIT.setExternalVBSLocation(
    PATH.join(PATH.dirname(APP.getPath("exe")), "resources/regedit/vbs")
);

const runtime = { GlobalSettings: null, SystemRootPath: process.env.SystemRoot };
function setGlobalSettings(oInfo) { runtime.GlobalSettings = oInfo; }

module.exports = {
    REMOTE, CURRWIN, PATH, APP, FS, REGEDIT, XMLJS, RANDOM,
    IPCRENDERER, spawn, exec, APPPATH, USERDATA,
    PATHINFO, WSUTIL, SETTINGS, runtime, setGlobalSettings,
};
