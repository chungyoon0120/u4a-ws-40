/**
 * ====================================================================
 *  [조립] 생명주기/창 제어 — lifecycle.js
 * --------------------------------------------------------------------
 *  역할   : 단일 인스턴스 보장, 창 이벤트, 작업표시줄 메뉴, 종료 흐름
 *  시점   : bootstrap.init() 초반
 *  입출력 : 입력: 없음 / 출력: Electron 창·앱 이벤트 바인딩
 *  구대응 : _ensureSingleInstance(L5625), _attachCurrentWindowEvents(L4750), onbeforeunload(L5704), _createTaskBarMenu(L4787), fnProgramShuttDown(L5403)
 *  의존   : ./env, widgets/confirmDialog
 * ====================================================================
 */
"use strict";

function ensureSingleInstance() { /* TODO: 구 L5625 */ }
function attachWindowEvents()   { /* TODO: 구 L4750 + onbeforeunload(L5704) */ }
function createTaskBarMenu()    { /* TODO: 구 L4787 */ }
function askShutdown()          { /* TODO: 구 showIllustratedMsg 대체(자체 모달) */ }
function programShutdown()      { /* TODO: 구 L5403 */ }

module.exports = { ensureSingleInstance, attachWindowEvents, createTaskBarMenu, askShutdown, programShutdown };
