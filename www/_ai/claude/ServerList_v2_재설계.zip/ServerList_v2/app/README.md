# app — 애플리케이션 조립

앱을 "어떻게 켜는가"만 담당. 진입 파일은 루트 `../ServerList.js`(HTML이 로드)이며,
이 폴더는 그 진입이 호출하는 조립 부품을 둔다. 도메인 로직은 services, 화면은 features.

| 파일 | 역할 | 구 대응 |
|------|------|---------|
| `env.js` | 네이티브 핸들 1곳 집약(REMOTE/FS/PATH/REGEDIT…) | 전역 require(L115~186) |
| `bootstrap.js` | 부팅 시퀀스(골격→데이터) | `fnOnMainStart`(L475) |
| `lifecycle.js` | 단일인스턴스/창/종료 | `_ensureSingleInstance`(L5625) 등 |

> 진입: `ServerList.html` → `<script src="./ServerList.js">` → `app/bootstrap.init()`.
> 부팅 순서는 `bootstrap.init()` 본문의 번호 주석(1~6)을 그대로 읽으면 된다.
