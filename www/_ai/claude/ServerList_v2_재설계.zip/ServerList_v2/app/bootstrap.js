/**
 * ====================================================================
 *  [조립] 부팅 시퀀스 — bootstrap.js
 * --------------------------------------------------------------------
 *  역할   : 화면 골격 먼저 → 데이터 적재 순서로 앱을 기동 (구 메인 시퀀스 계승)
 *  시점   : ServerList.js 가 글로벌설정 수신(또는 dev-fallback) 후 1회 호출
 *  입출력 : 입력: 없음 / 출력: 화면 마운트 + 상태 적재 + Named Pipe 서버
 *  구대응 : fnOnMainStart (L475)
 *  의존   : lifecycle, i18n, features/shell, services/*, ipc/netServer, widgets/busyIndicator
 * ====================================================================
 */
"use strict";

const { CURRWIN } = require("./env");
const lifecycle = require("./lifecycle");
const busy = require("../widgets/busyIndicator");
const i18n = require("../i18n");
const shell = require("../features/shell/shell.view");
const systemPort = require("../services/servicesPort.service");
const landscape = require("../services/landscape.service");
const netServer = require("../ipc/netServer");

async function init() {
    busy.show();
    try {
        // 1) 생명주기/창
        lifecycle.ensureSingleInstance();
        lifecycle.attachWindowEvents();
        lifecycle.createTaskBarMenu();

        // 2) 다국어 → 3) 화면 골격 (여기까지만 돼도 화면은 보인다)
        await i18n.load();
        shell.render();
        shell.applyI18n();
        console.log("[bootstrap] 화면 골격 렌더 완료");

        // 4) 메시지서버 포트 → 5) 서버 목록 적재(레지스트리/XML)
        await systemPort.loadMsgServPortList();
        await landscape.listupSapLogon();

        // 6) 외부 연동 서버 (실패해도 화면에는 영향 없음)
        try { await netServer.createServer(); }
        catch (e) { console.error("[bootstrap] netServer 기동 실패:", e); }

    } catch (e) {
        console.error("[bootstrap] 초기화 중 오류:", e);
    } finally {
        busy.hide();                 // 어떤 단계가 실패해도 Busy 는 반드시 해제
        try { CURRWIN.focus(); } catch (_) {}
    }
}
module.exports = { init };
