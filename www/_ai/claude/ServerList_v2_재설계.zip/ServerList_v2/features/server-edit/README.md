# features/server-edit — 등록 / 수정 / 옵션

서버 접속정보(Protocol/Host/Port)와 옵션을 입력·저장하는 모달들.

| 파일 | 역할 | 구 대응 |
|------|------|---------|
| `editDialog.view.js` | 접속정보 등록/수정 + 검증 | `fnEditDialogOpen`(L3180)/`fnPressSave`(L3652)/`fnCheckValid`(L3799) |
| `settingsDialog.view.js` | 서버별 옵션 편집 | `fnOpenServerSettings` (L2851) |

저장 위치: `serverInfo_v2.json` (services/serverStore)
