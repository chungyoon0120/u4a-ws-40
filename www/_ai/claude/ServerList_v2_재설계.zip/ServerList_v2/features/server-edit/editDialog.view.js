/**
 * ====================================================================
 *  [기능:편집] 등록/수정 — editDialog.view.js
 * --------------------------------------------------------------------
 *  역할   : Protocol(select)+Host(필수)+Port 입력 모달, 검증 후 저장
 *  시점   : 미저장 행 더블클릭 / Edit 클릭 시
 *  입출력 : 입력: serverData / 출력: serverStore.upsert + 모델 ISSAVE=true
 *  구대응 : fnEditDialogOpen(L3180), fnPressSave(L3652), fnCheckValid(L3799)
 *  의존   : widgets/modal, services/serverStore, services/sound, widgets/toast
 * ====================================================================
 */
"use strict";

const modal = require("../../widgets/modal");
function open(serverData) { /* TODO */ }
function save()           { /* TODO: 구 fnPressSave */ }
function validate(data)   { /* TODO: host 필수/공백 */ }
module.exports = { open, save, validate };
