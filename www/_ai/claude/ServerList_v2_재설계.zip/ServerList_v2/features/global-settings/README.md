# features/global-settings — 글로벌 설정

서브헤더의 설정 메뉴: 언어 / 테마 / 사운드 / About.

| 파일 | 역할 | 구 대응 |
|------|------|---------|
| `settingsMenu.view.js` | 드롭다운 메뉴 | `MenuButton/Menu` (L1807) |
| `settings.handler.js` | 항목별 팝업·저장 분기 | `ev_settingItemSelected` (L3962) + 각 팝업(L4003~) |
