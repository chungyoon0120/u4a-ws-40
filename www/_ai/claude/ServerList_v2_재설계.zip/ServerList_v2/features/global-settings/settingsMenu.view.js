/**
 * ====================================================================
 *  [기능:설정] 설정 메뉴 — settingsMenu.view.js
 * --------------------------------------------------------------------
 *  역할   : 서브헤더 우측 설정 버튼(언어/테마/사운드/About)
 *  시점   : shell mount 후
 *  입출력 : 출력: 버튼 HTML (메뉴 로직은 handler에서 확장)
 *  구대응 : MenuButton/Menu(L1807)
 *  의존   : ./settings.handler
 * ====================================================================
 */
"use strict";

// const handler = require("./settings.handler"); // TODO: 메뉴 오픈 연결
function markup() {
    return `<button id="ws-settings-btn" class="ws-btn" title="Settings">&#9881;</button>`;
}
function wire() {
    // TODO: 클릭 시 드롭다운(언어/테마/사운드/About) → settings.handler.onSelect(key)
}
module.exports = { markup, wire };
