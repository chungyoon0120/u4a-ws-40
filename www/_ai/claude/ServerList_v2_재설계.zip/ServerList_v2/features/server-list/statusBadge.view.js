/**
 * ====================================================================
 *  [기능:목록] 상태 배지 — statusBadge.view.js
 * --------------------------------------------------------------------
 *  역할   : ISSAVE → Active(초록)/Inactive(회색) 점+라벨 markup
 *  시점   : 테이블 행 렌더 시
 *  입출력 : 입력: bIsSave / 출력: HTML 문자열
 *  구대응 : sap.m.ObjectStatus(L2198)
 *  의존   : styles/components.css(.ws-status)
 * ====================================================================
 */
"use strict";

function html(bIsSave) {
    const on = bIsSave === true;
    const cls = on ? "ws-status--active" : "ws-status--inactive";
    const txt = on ? "Active" : "Inactive";
    return `<span class="ws-status ${cls}"><span class="ws-status__dot"></span>${txt}</span>`;
}
module.exports = { html };
