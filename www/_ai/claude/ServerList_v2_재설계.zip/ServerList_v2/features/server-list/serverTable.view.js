/**
 * ====================================================================
 *  [기능:목록] 서버 목록 뷰 — serverTable.view.js
 * --------------------------------------------------------------------
 *  역할   : 6컬럼 테이블(데스크톱)/카드(모바일), 더블클릭 실행/툴바(추후 확장)
 *  시점   : shell mount 후 / SAPLogonItems 변경 시
 *  입출력 : 입력: STATE.SAPLogonItems / 출력: #ws-server-table
 *  구대응 : fnGetSAPLogonListTable(L2190)
 *  의존   : core/constants, ./statusBadge.view, ./serverAction.handler
 * ====================================================================
 */
"use strict";

const { DOM, FIELD } = require("../../core/constants");
const statusBadge = require("./statusBadge.view");
const action = require("./serverAction.handler");

const COLS = [
    { key: FIELD.SAVED, label: "STATUS" },
    { key: FIELD.NAME,  label: "SERVER NAME" },
    { key: FIELD.SID,   label: "SID", center: true },
    { key: FIELD.HOST,  label: "HOST(Or IP)" },
    { key: FIELD.SNO,   label: "SNO", center: true },
    { key: "_settings", label: "Settings", center: true },
];

function _row(it) {
    const cell = (c) => {
        if (c.key === FIELD.SAVED)  return statusBadge.html(it[FIELD.SAVED]);
        if (c.key === "_settings")  return `<button class="ws-gear" ${it[FIELD.SAVED] ? "" : "disabled"} title="Settings">&#9881;</button>`;
        return it[c.key] != null ? String(it[c.key]) : "";
    };
    return `<tr data-uuid="${it[FIELD.UUID] || ""}">` +
        COLS.map((c) => `<td data-label="${c.label}" class="${c.center ? "ws-col--center" : ""}">${cell(c)}</td>`).join("") +
        `</tr>`;
}

function render(items) {
    const root = document.getElementById(DOM.SERVER_TABLE);
    if (!root) return;
    const list = Array.isArray(items) ? items : [];

    const toolbar = `<div class="ws-table-toolbar">
        <button class="ws-btn-edit"   id="ws-tb-edit">&#9998;</button>
        <button class="ws-btn-delete" id="ws-tb-delete">&#128465;</button>
      </div>`;

    const head = `<thead><tr>` +
        COLS.map((c) => `<th class="${c.center ? "ws-col--center" : ""}">${c.label}</th>`).join("") +
        `</tr></thead>`;

    const body = list.length
        ? `<tbody>${list.map(_row).join("")}</tbody>`
        : `<tbody><tr><td colspan="${COLS.length}" style="text-align:center;color:var(--ws-text-muted);padding:24px">표시할 서버가 없습니다. (좌측에서 폴더를 선택하세요)</td></tr></tbody>`;

    root.innerHTML = toolbar + `<table class="ws-table">${head}${body}</table>`;

    // 더블클릭 실행
    root.querySelectorAll("tbody tr[data-uuid]").forEach((tr) => {
        tr.ondblclick = () => action.onActivate(tr.getAttribute("data-uuid"));
    });
    const e = document.getElementById("ws-tb-edit");   if (e) e.onclick = () => action.onEdit();
    const d = document.getElementById("ws-tb-delete"); if (d) d.onclick = () => action.onDelete();
}
function sortBy() { /* TODO */ }
function clearSelection() { /* TODO */ }
module.exports = { render, sortBy, clearSelection };
