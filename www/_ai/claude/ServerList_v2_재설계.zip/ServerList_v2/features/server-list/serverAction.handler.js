/**
 * ====================================================================
 *  [기능:목록] 행 액션 — serverAction.handler.js
 * --------------------------------------------------------------------
 *  역할   : 더블클릭 실행 / Edit / Delete 처리
 *  시점   : 행 더블클릭·툴바 클릭 시
 *  입출력 : 입력: uuid / 출력: editDialog 열기 또는 login 실행, 삭제 저장
 *  구대응 : fnPressServerListItem(L3879), fnPressEdit(L3043), fnPressDelete(L3069)
 *  의존   : services/login, services/serverStore, services/theme, widgets/confirmDialog, ../server-edit/editDialog.view
 * ====================================================================
 */
"use strict";

function onActivate(uuid) { /* TODO: 미저장→edit / 저장→login.openLogin */ }
function onEdit()         { /* TODO */ }
function onDelete()       { /* TODO: confirm 후 serverStore.remove */ }
module.exports = { onActivate, onEdit, onDelete };
