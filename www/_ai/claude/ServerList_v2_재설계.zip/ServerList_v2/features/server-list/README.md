# features/server-list — 우측 서버 목록

선택한 폴더의 서버를 표(데스크톱)/카드(모바일)로 보여주고, 실행·편집·삭제를 처리한다.

| 파일 | 역할 | 구 대응 |
|------|------|---------|
| `serverTable.view.js` | 6컬럼 표/카드, 정렬, 더블클릭, 툴바 | `fnGetSAPLogonListTable` (L2190) |
| `statusBadge.view.js` | Active/Inactive 점·라벨 | `sap.m.ObjectStatus` (L2198) |
| `serverAction.handler.js` | 실행/Edit/Delete | `fnPressServerListItem`(L3879)/`fnPressEdit`(L3043)/`fnPressDelete`(L3069) |

컬럼: STATUS · SERVER NAME · SID · HOST(Or IP) · SNO · Settings
관련 스타일: `styles/components.css (.ws-table/.ws-status)`, `styles/responsive.css(카드)`
