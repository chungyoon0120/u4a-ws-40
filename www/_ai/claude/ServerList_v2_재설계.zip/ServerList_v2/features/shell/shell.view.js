/**
 * ====================================================================
 *  [기능:골격] 화면 골격 — shell.view.js
 * --------------------------------------------------------------------
 *  역할   : 헤더+서브헤더+2분할(좌 트리/우 목록) DOM 생성 후 #app 마운트, 자식 뷰 연결+구독
 *  시점   : 부팅 3단계
 *  입출력 : 출력: #app DOM, 트리/테이블 mount, store 구독
 *  구대응 : fnOnInitRendering(L1691)
 *  의존   : core/constants·store·state, ./titlebar.view, ../workspace-tree/tree.view, ../server-list/serverTable.view, ../global-settings/settingsMenu.view
 * ====================================================================
 */
"use strict";

const { DOM } = require("../../core/constants");
const store = require("../../core/store");
const STATE = require("../../core/state");
const titlebar = require("./titlebar.view");
const settingsMenu = require("../global-settings/settingsMenu.view");
const tree = require("../workspace-tree/tree.view");
const serverTable = require("../server-list/serverTable.view");

function render() {
    const app = document.getElementById(DOM.APP);
    if (!app) { console.error("[shell] #app 엘리먼트를 찾을 수 없습니다."); return; }

    app.innerHTML = `
      <div class="ws-shell">
        ${titlebar.markup()}
        <div class="ws-subheader">
          <span data-i18n="ZMSG_WS_COMMON_001/004">U4A Workspace Logon Pad</span>
          <span class="ws-actions">${settingsMenu.markup()}</span>
        </div>
        <div class="ws-body">
          <div class="ws-pane ws-pane--tree" id="${DOM.TREE}"></div>
          <div class="ws-pane" id="${DOM.SERVER_TABLE}"></div>
        </div>
      </div>`;

    // 보이기
    app.hidden = false;

    // 자식 뷰 이벤트 연결
    titlebar.wire();
    settingsMenu.wire();

    // 초기 렌더 (현재 상태 기준; 비어 있어도 틀은 보임)
    tree.render(STATE.SAPLogon);
    serverTable.render(STATE.SAPLogonItems);

    // 상태 변경 구독 → 부분 재렌더
    store.subscribe("SAPLogon", (v) => tree.render(v));
    store.subscribe("SAPLogonItems", (v) => serverTable.render(v));
}

// 다국어 텍스트 치환 (data-i18n="ARBGB/MSGNR")
function applyI18n() {
    const i18n = require("../../i18n");
    document.querySelectorAll("[data-i18n]").forEach((el) => {
        const [arbgb, msgnr] = (el.getAttribute("data-i18n") || "").split("/");
        const txt = i18n.t && i18n.t(arbgb, msgnr);
        if (txt) el.textContent = txt;
    });
}
module.exports = { render, applyI18n };
