/**
 * ====================================================================
 *  [기능:골격] 타이틀바 — titlebar.view.js
 * --------------------------------------------------------------------
 *  역할   : 로고/타이틀 + 최소화·최대화·닫기 버튼 (Electron 프레임리스)
 *  시점   : shell.render() 내부
 *  입출력 : 출력: 헤더 HTML + 버튼 이벤트 바인딩
 *  구대응 : customHeader 버튼(L1731~)
 *  의존   : app/env(CURRWIN)
 * ====================================================================
 */
"use strict";

const { CURRWIN } = require("../../app/env");

// 헤더 마크업 (좌: 타이틀 / 우: 창 제어 버튼)
function markup() {
    return `
      <div class="ws-header">
        <strong>U4A Workspace</strong>
        <div class="ws-winbtns">
          <button id="ws-win-min"   title="Minimize">&#8211;</button>
          <button id="ws-win-max"   title="Maximize">&#9633;</button>
          <button id="ws-win-close" title="Close">&#10005;</button>
        </div>
      </div>`;
}

// 버튼 이벤트 연결 (DOM 삽입 후 호출)
function wire() {
    const min = document.getElementById("ws-win-min");
    const max = document.getElementById("ws-win-max");
    const close = document.getElementById("ws-win-close");
    if (min)  min.onclick  = () => CURRWIN.minimize();
    if (max)  max.onclick  = () => (CURRWIN.isMaximized() ? CURRWIN.unmaximize() : CURRWIN.maximize());
    if (close) close.onclick = () => CURRWIN.close(); // TODO: 자식창 체크 후 askShutdown
}
module.exports = { markup, wire };
