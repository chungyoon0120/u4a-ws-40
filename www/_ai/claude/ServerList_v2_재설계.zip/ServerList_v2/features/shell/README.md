# features/shell — 앱 골격

상단 헤더 · 서브헤더 · 좌우 2분할 레이아웃을 만들고, 각 기능 뷰(트리/목록/설정)를 끼운다.

| 파일 | 역할 | 구 대응 |
|------|------|---------|
| `shell.view.js` | 전체 골격 DOM 생성·마운트 | `fnOnInitRendering` (L1691) |
| `titlebar.view.js` | 창 최소/최대/닫기 | customHeader 버튼 (L1731~) |

관련 스타일: `styles/layout.css`
