/**
 * ====================================================================
 *  [기능:트리] 선택 핸들러 — treeSelect.handler.js
 * --------------------------------------------------------------------
 *  역할   : 노드 선택 → 하위 서버를 ServerList에서 매칭 → SAPLogonItems 구성·정렬·병합
 *  시점   : 트리 행 클릭 시
 *  입출력 : 입력: uuid / 출력: STATE.SAPLogonItems 갱신(테이블 자동 렌더)
 *  구대응 : fnPressWorkSpaceTreeItem(L1943)
 *  의존   : core/store, services/serverStore, services/registry
 * ====================================================================
 */
"use strict";

function onSelect(uuid) { /* TODO: SAPLogonItems 구성 + syncSavedInfo + setLastSelectedNodeKey */ }
module.exports = { onSelect };
