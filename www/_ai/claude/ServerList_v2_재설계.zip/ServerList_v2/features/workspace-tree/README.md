# features/workspace-tree — 좌측 워크스페이스 트리

폴더 계층(`STATE.SAPLogon`)을 그리고, 선택하면 우측 서버 목록을 채운다.

| 파일 | 역할 | 구 대응 |
|------|------|---------|
| `tree.view.js` | 트리 렌더/펼침/선택/복원 | `fnGetWorkSpaceTreeTable` (L1881) + `fnAttachRowsUpdateOnce`(L662) |
| `treeSelect.handler.js` | 선택→우측 목록 구성·병합 | `fnPressWorkSpaceTreeItem` (L1943) |

관련 스타일: `styles/components.css (.ws-tree)`
