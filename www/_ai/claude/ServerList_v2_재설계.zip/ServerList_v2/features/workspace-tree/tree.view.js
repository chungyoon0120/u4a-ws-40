/**
 * ====================================================================
 *  [기능:트리] 좌측 트리 뷰 — tree.view.js
 * --------------------------------------------------------------------
 *  역할   : STATE.SAPLogon 재귀 렌더, 선택/펼침(추후 확장)
 *  시점   : shell mount 후 / SAPLogon 변경 시
 *  입출력 : 입력: STATE.SAPLogon / 출력: #ws-tree, 선택시 핸들러 호출
 *  구대응 : fnGetWorkSpaceTreeTable(L1881)
 *  의존   : core/constants, ./treeSelect.handler
 * ====================================================================
 */
"use strict";

const { DOM } = require("../../core/constants");
const handler = require("./treeSelect.handler");

function _renderNodes(aNode) {
    if (!Array.isArray(aNode) || aNode.length === 0) return "";
    return `<ul class="ws-tree__children">` + aNode.map((n) => {
        const a = n._attributes || {};
        const kids = n.Node ? _renderNodes(n.Node) : "";
        return `<li>
            <div class="ws-tree__node" data-uuid="${a.uuid || ""}">
              <span class="ws-tree__toggle">${n.Node ? "▸" : ""}</span>
              <span>${a.name || "(no name)"}</span>
            </div>${kids}
          </li>`;
    }).join("") + `</ul>`;
}

function render(treeData) {
    const root = document.getElementById(DOM.TREE);
    if (!root) return;
    const nodes = (treeData && treeData.Node) ? treeData.Node : [];
    root.innerHTML = nodes.length
        ? `<div class="ws-tree">${_renderNodes(nodes)}</div>`
        : `<div class="ws-tree" style="padding:12px;color:var(--ws-text-muted)">표시할 워크스페이스가 없습니다.</div>`;

    // 선택 이벤트 (위임)
    root.querySelectorAll(".ws-tree__node").forEach((el) => {
        el.onclick = () => {
            root.querySelectorAll(".ws-tree__node").forEach((x) => x.classList.remove("is-selected"));
            el.classList.add("is-selected");
            handler.onSelect(el.getAttribute("data-uuid"));
        };
    });
}
function expandToLevel() { /* TODO */ }
function select() { /* TODO */ }
module.exports = { render, expandToLevel, select };
