# styles — 스타일

`ServerList.html` 에서 아래 순서로 로드(앞이 토대). 색·간격·폰트는 전부 `tokens.css` 변수로 통일.

| 파일 | 역할 |
|------|------|
| `tokens.css` | 디자인 토큰(색/간격/폰트) — 테마 전환 시 여기만 교체 |
| `base.css` | 리셋/타이포/앱 루트 |
| `busy.css` | Busy Indicator |
| `layout.css` | shell 골격(헤더/2분할) |
| `components.css` | 트리/표/배지/모달/토스트/메뉴 |
| `responsive.css` | 데스크톱→태블릿(드로어)→모바일(카드) |

테마: 기존 SAP Horizon Dark 계승(다크 네이비 + 초록 Active 점).
