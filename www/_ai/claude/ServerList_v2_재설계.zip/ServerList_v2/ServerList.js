/**
 * ====================================================================
 *  [진입] ServerList.js  —  애플리케이션 시작점 (HTML이 직접 로드)
 * --------------------------------------------------------------------
 *  역할   : 네이티브 핸들 준비 → Electron 글로벌설정 수신 → bootstrap.init()
 *  시점   : ServerList.html 의 <script src="./ServerList.js"> 로드 직후
 *  입출력 : 입력 ipc 'if-globalSetting-info' / 출력 bootstrap.init()
 *  구대응 : 구 ServerList.js 상단 IIFE(L12~112) + if-globalSetting-info(L31)
 *  의존   : ./app/env, ./app/bootstrap, ./ipc/rendererIpc
 *  비고   : 루트 파일이므로 <script src> 로 로드해도 require("./app/...") 정상.
 * ====================================================================
 */
"use strict";

console.log("[ServerList] entry loaded");

const env = require("./app/env");
const bootstrap = require("./app/bootstrap");
const rendererIpc = require("./ipc/rendererIpc");

let _started = false;
function start(reason) {
    if (_started) return;
    _started = true;
    console.log(`[ServerList] bootstrap.init() 시작 (트리거: ${reason})`);
    Promise.resolve(bootstrap.init()).catch((e) => {
        console.error("[ServerList] bootstrap.init() 실패:", e);
    });
}

// 정상 경로: 메인 프로세스가 글로벌 설정을 보내면 시작
rendererIpc.onGlobalSetting((oInfo) => {
    env.setGlobalSettings(oInfo);
    start("if-globalSetting-info");
});

/**
 * 개발용 안전장치
 * - 메인 프로세스가 'if-globalSetting-info' 를 보내지 않으면 init 이 영영 안 돈다.
 * - 1.5초 내 이벤트가 없으면 경고를 남기고 화면 골격만이라도 띄운다(데이터는 비어 있음).
 *   → 화면이 안 보이는 원인이 'IPC 미수신' 인지 '구현 누락' 인지 즉시 구분 가능.
 */
setTimeout(() => {
    if (!_started) {
        console.warn("[ServerList] 'if-globalSetting-info' 미수신 — 메인 프로세스가 이벤트를 보냈는지 확인하세요. (개발용으로 골격만 먼저 렌더)");
        start("dev-fallback(no-ipc)");
    }
}, 1500);
