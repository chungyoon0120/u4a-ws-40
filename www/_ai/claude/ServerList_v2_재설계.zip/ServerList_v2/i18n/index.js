/**
 * ====================================================================
 *  [다국어] 로더 — i18n/index.js
 * --------------------------------------------------------------------
 *  역할   : 레지스트리 언어 기준 메시지 텍스트 적재 + 조회 t()
 *  시점   : 부팅 2단계
 *  입출력 : 출력: STATE.WSLANGU, t(arbgb,msgnr)
 *  구대응 : fnWsGlobalMsgList(L533) + fnOnInitModeling(L606)
 *  의존   : core/state, app/env(WSUTIL)
 * ====================================================================
 */
"use strict";

const STATE = require("../core/state");
async function load() { /* TODO: 메시지 적재 → STATE.WSLANGU */ }
function t(arbgb, msgnr) { /* TODO */ }
module.exports = { load, t };
