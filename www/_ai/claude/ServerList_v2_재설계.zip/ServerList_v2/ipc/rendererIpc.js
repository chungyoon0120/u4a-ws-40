/**
 * ====================================================================
 *  [연동] 렌더러 IPC — rendererIpc.js
 * --------------------------------------------------------------------
 *  역할   : Electron ipcRenderer on/send 호출 일원화
 *  시점   : 글로벌설정 수신 / 로그인창 메타 전송 시
 *  입출력 : 입력: 채널/콜백 / 출력: 메시지 송수신
 *  구대응 : if-globalSetting-info(L31), if-meta-info send(L5123)
 *  의존   : app/env(IPCRENDERER)
 * ====================================================================
 */
"use strict";

const { IPCRENDERER } = require("../app/env");
function onGlobalSetting(cb) { IPCRENDERER.on("if-globalSetting-info", (e, oInfo) => cb(oInfo)); }
function sendMeta(oWebContents, oMeta) { oWebContents.send("if-meta-info", oMeta); }
module.exports = { onGlobalSetting, sendMeta };
