/**
 * ====================================================================
 *  [연동] PRCCD 핸들러 — handlers/openServer.js
 * --------------------------------------------------------------------
 *  역할   : Named Pipe 요청 중 'openServer' 처리
 *  시점   : netServer 라우팅 시
 *  입출력 : 입력: (oStream, oIF) / 출력: oStream.write 응답
 *  구대응 : modules/Server/net/PRC_MODULES/<openServer>/index.js
 *  의존   : 없음(스트림 직접)
 * ====================================================================
 */
"use strict";

module.exports = function (oStream, oIF) {
    // TODO: 구 PRC_MODULES 로직 이식
};
