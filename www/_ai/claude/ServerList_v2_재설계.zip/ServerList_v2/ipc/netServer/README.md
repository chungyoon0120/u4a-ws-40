# ipc/netServer — Named Pipe 서버

파이프(`\\.\pipe\u4aws\serverlist`)로 들어온 JSON의 `PRCCD` 를 보고 `handlers/` 의 해당 파일을 실행한다.
구 `PRC_MODULES/<코드>/index.js` 를 `handlers/<코드>.js` 단일 파일로 평탄화했다(동작 동일).
