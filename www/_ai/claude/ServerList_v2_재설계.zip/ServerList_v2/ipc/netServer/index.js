/**
 * ====================================================================
 *  [연동] Named Pipe 서버 — netServer/index.js
 * --------------------------------------------------------------------
 *  역할   : 외부 프로그램(U4A EDU 등)과 Named Pipe 통신, PRCCD로 handler 라우팅
 *  시점   : 부팅 6단계 (모델 적재 후)
 *  입출력 : 입력: 파이프 JSON / 출력: handler 실행·응답
 *  구대응 : modules/Server/net/index.js (createServer)
 *  의존   : net, app/env(APP), ./handlers/*
 * ====================================================================
 */
"use strict";

const NET = require("net");
const PATH = require("path");
const { APP } = require("../../app/env"); // 네이티브 핸들은 env에서 (remote.app)

const TY_RES = { PRCCD: "", ACTCD: "", RETCD: "", STCOD: "", RTMSG: "", RDATA: "" };
const HANDLER_DIR = PATH.join(__dirname, "handlers");
const PIPENAME = "\\\\.\\pipe\\u4aws\\serverlist" + (APP.isPackaged ? "" : "_dev");

// PRCCD → 핸들러 파일 (구 PRC_MODULES 폴더명과 1:1)
const HANDLER_MAP = {
    CONNECT: "connect", DISCONNECT: "disconnect", ISCONNECT: "isConnect",
    OPEN_SERVER: "openServer", WS20: "ws20", TEST: "test",
};

function createServer() {
    return new Promise((resolve) => {
        const oServer = NET.createServer((oStream) => {
            oStream.on("data", (data) => {
                let _oRES = JSON.parse(JSON.stringify(TY_RES));
                try {
                    const _oIF = JSON.parse(data.toString());
                    const name = HANDLER_MAP[_oIF.PRCCD];
                    if (!name) throw new Error("unsupported PRCCD");
                    require(PATH.join(HANDLER_DIR, name + ".js"))(oStream, _oIF);
                } catch (e) {
                    _oRES.RETCD = "E"; _oRES.STCOD = "E002";
                    require(PATH.join(HANDLER_DIR, "error.js"))(oStream, _oRES);
                }
            });
            oStream.on("error", () => {});
        });
        oServer.on("error", () => {});
        oServer.listen(PIPENAME, () => resolve(oServer));
    });
}
module.exports = { createServer, TY_RES };
