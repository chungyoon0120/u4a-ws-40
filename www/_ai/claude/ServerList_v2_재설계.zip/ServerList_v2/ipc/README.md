# ipc — Electron / 외부 연동

| 경로 | 역할 | 구 대응 |
|------|------|---------|
| `rendererIpc.js` | ipcRenderer on/send 모음 | `if-globalSetting-info`(L31) 등 |
| `netServer/` | 외부 프로그램용 Named Pipe 서버 | `modules/Server/net/*` |
| `netServer/handlers/` | PRCCD별 처리기 | `PRC_MODULES/<코드>/index.js` |

> handler 추가법: `handlers/<이름>.js` 생성 후 `netServer/index.js` 의 `HANDLER_MAP` 에 `PRCCD: "<이름>"` 등록.
