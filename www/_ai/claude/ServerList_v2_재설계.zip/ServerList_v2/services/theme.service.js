/**
 * ====================================================================
 *  [서비스] 테마 개인화 — theme.service.js
 * --------------------------------------------------------------------
 *  역할   : SYSID별 사용자 테마 정보 조회/생성
 *  시점   : 행 더블클릭 실행 직전
 *  입출력 : 입력: SYSID / 출력: 테마정보
 *  구대응 : fnP13nCreateTheme(L5146), _getThemeInfoRegAsync(L4162)
 *  의존   : app/env(REGEDIT)
 * ====================================================================
 */
"use strict";

async function createTheme(SYSID) { /* TODO */ }
module.exports = { createTheme };
