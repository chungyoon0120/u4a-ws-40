/**
 * ====================================================================
 *  [서비스] 서버 실행/로그인 창 — login.service.js
 * --------------------------------------------------------------------
 *  역할   : 선택 서버 접속정보로 새 BrowserWindow(로그인) 생성
 *  시점   : 행 더블클릭 실행 시
 *  입출력 : 입력: oLoginInfo / 출력: 새 창 + if-meta-info 전송
 *  구대응 : fnLoginPage(L5029), _registSelectedSystemInfo(L4643), configureSession(L4941)
 *  의존   : app/env(REMOTE,RANDOM,PATHINFO), ipc/rendererIpc
 * ====================================================================
 */
"use strict";

async function openLogin(oLoginInfo)        { /* TODO */ }
async function registSelectedSystemInfo(o)  { /* TODO */ }
module.exports = { openLogin, registSelectedSystemInfo };
