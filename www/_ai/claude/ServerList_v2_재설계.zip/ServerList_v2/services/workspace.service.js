/**
 * ====================================================================
 *  [서비스] 워크스페이스 트리 데이터 — workspace.service.js
 * --------------------------------------------------------------------
 *  역할   : 좌측 트리 데이터 구성/정렬 + 마지막 선택 노드 경로 탐색
 *  시점   : 데이터 적재 시 / 트리 최초 렌더 후
 *  입출력 : 입력: Landscape.Workspaces / 출력: STATE.SAPLogon, 선택경로
 *  구대응 : fnCreateWorkspaceTree(L2117), fnWorkSpaceSort(L2141), _findLastSelectedPath(L754)
 *  의존   : core/state
 * ====================================================================
 */
"use strict";

function buildTree()                       { /* TODO */ }
function sortNodes(aNode)                  { /* TODO: 이름 오름차순 재귀 */ }
function findLastSelectedPath(aTree, sKey, aPaths) { /* TODO */ }
module.exports = { buildTree, sortNodes, findLastSelectedPath };
