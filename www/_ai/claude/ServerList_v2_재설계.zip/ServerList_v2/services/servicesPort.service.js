/**
 * ====================================================================
 *  [서비스] etc/services 포트 — servicesPort.service.js
 * --------------------------------------------------------------------
 *  역할   : Windows etc/services 에서 메시지서버 SYSID/PORT 추출
 *  시점   : 부팅 4단계
 *  입출력 : 출력: [{SYSID,PORT}] (모듈 캐시/STATE)
 *  구대응 : _getMsgServPortList(L339), _getSys32Services(L306)
 *  의존   : app/env(exec, runtime.SystemRootPath)
 * ====================================================================
 */
"use strict";

async function loadMsgServPortList() { /* TODO: findstr sapms → 파싱 */ }
function getPortBySysid(sysid)       { /* TODO */ }
module.exports = { loadMsgServPortList, getPortBySysid };
