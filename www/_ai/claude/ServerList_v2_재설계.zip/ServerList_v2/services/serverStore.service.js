/**
 * ====================================================================
 *  [서비스] 저장 서버정보 CRUD — serverStore.service.js
 * --------------------------------------------------------------------
 *  역할   : serverInfo_v2.json 읽기/저장/삭제 + 현재 목록과 병합(ISSAVE)
 *  시점   : 조회 병합 / 등록·수정·삭제 시
 *  입출력 : 입력: uuid/레코드 / 출력: 저장데이터, 병합결과
 *  구대응 : fnGetSavedServerListData(All)(L3372/3425), fnPressSave저장부(L3652), fnPressDelete저장부(L3069), _saveServerSettings(L2764), _syncSavedServerInfo(L2708)
 *  의존   : app/env(FS,PATHINFO)
 * ====================================================================
 */
"use strict";

function getAll()                  { /* TODO */ }
function getByUuid(uuid)           { /* TODO */ }
function upsert(oRecord)           { /* TODO */ }
function remove(uuid)              { /* TODO */ }
function saveSettings(uuid, oSet)  { /* TODO: 구 _saveServerSettings */ }
function syncSavedInfo(aItems)     { /* TODO: ISSAVE/settings 주입 */ }
module.exports = { getAll, getByUuid, upsert, remove, saveSettings, syncSavedInfo };
