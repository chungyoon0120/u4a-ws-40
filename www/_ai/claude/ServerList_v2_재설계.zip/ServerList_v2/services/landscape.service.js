/**
 * ====================================================================
 *  [서비스] Landscape XML — landscape.service.js
 * --------------------------------------------------------------------
 *  역할   : SAPUILandscape.xml 읽기·파싱·가공 + 서버목록 적재 오케스트레이션
 *  시점   : 부팅 5단계 / XML 파일 변경 감지 시
 *  입출력 : 입력: 레지스트리 경로 / 출력: STATE.ServerList·SAPLogon 갱신
 *  구대응 : fnOnListupSapLogon(L849), fnReadSAPLogonData(L1422), fnSetSAPLogonLandscapeList(L1461), fnSapLogonFileChange(L985)
 *  의존   : core/store, registry/sapgui/workspace.service, app/env(FS,XMLJS)
 * ====================================================================
 */
"use strict";

const store = require("../core/store");
async function listupSapLogon() { /* TODO: 레지스트리→XML→버전체크→가공→트리 (구 흐름) */ }
function readXml(sFilePath)     { /* TODO: FS.readFile + XMLJS.xml2json */ }
function buildServerList()      { /* TODO: services/routers/msgservers 가공, insno 계산 → STATE.ServerList */ }
function onFileChange()         { /* TODO: debounce 후 listupSapLogon() */ }
module.exports = { listupSapLogon, readXml, buildServerList, onFileChange };
