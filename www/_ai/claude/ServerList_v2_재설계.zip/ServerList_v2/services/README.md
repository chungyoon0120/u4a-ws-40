# services — 도메인 / 네이티브 서비스

레지스트리·파일·PowerShell·창 생성 등 "무엇을 한다"를 담는 곳. 여러 feature 가 공유한다.
모든 네이티브 접근은 `app/env.js` 핸들을 사용(= remote/require 직접, preload 없음).

| 파일 | 한 줄 역할 |
|------|-----------|
| `registry.service.js` | 레지스트리 R/W |
| `landscape.service.js` | SAPUILandscape.xml 읽기·가공·적재 |
| `workspace.service.js` | 좌측 트리 데이터 구성·정렬 |
| `serverStore.service.js` | serverInfo_v2.json CRUD·병합 |
| `sapgui.service.js` | SAPGUI 버전 체크(PowerShell) |
| `servicesPort.service.js` | etc/services 포트 추출 |
| `login.service.js` | 서버 실행/로그인 창 |
| `theme.service.js` | 테마 개인화 |
| `sound.service.js` | 알림음 |

> 각 파일 상단 박스 헤더의 "구대응" 줄에 옛 함수·라인이 적혀 있다.
