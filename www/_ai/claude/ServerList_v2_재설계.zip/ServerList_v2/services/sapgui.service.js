/**
 * ====================================================================
 *  [서비스] SAPGUI 버전 — sapgui.service.js
 * --------------------------------------------------------------------
 *  역할   : 설치된 SAPGUI 버전/경로 확인 (PowerShell), 770 미만 차단
 *  시점   : XML 읽은 직후
 *  입출력 : 출력: { RETCD, RTVER, RTPATH }
 *  구대응 : fnCheckSapguiVersion(L1320), _checkSapGuiInfoShell(L1213)
 *  의존   : app/env(spawn)
 * ====================================================================
 */
"use strict";

async function checkVersion() { /* TODO: PowerShell get_sapgui_inf.ps1 */ }
module.exports = { checkVersion };
