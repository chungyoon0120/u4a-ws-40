/**
 * ====================================================================
 *  [서비스] 레지스트리 — registry.service.js
 * --------------------------------------------------------------------
 *  역할   : Windows 레지스트리 읽기/쓰기 (SAPLogon 경로, 마지막선택, GUIVer 등)
 *  시점   : 데이터 적재/선택 저장 시
 *  입출력 : 입력: 경로/키 / 출력: 값(Promise)
 *  구대응 : fnGetRegInfoForSAPLogon(L878), setRegistryLastSelectedNodeKey(L2056), _getRegeditList(L4693), GUIVer저장(L1068~)
 *  의존   : app/env(REGEDIT,SETTINGS)
 * ====================================================================
 */
"use strict";

async function getSapLogonRegInfo()        { /* TODO */ }
async function getList(aPaths)             { /* TODO: 구 _getRegeditList */ }
async function createKey(aKeys)            { /* TODO */ }
async function setLastSelectedNodeKey(u)   { /* TODO */ }
async function getLastSelectedNodeKey()    { /* TODO */ }
async function saveSapGuiInfo(ver, path)   { /* TODO */ }
module.exports = { getSapLogonRegInfo, getList, createKey, setLastSelectedNodeKey, getLastSelectedNodeKey, saveSapGuiInfo };
