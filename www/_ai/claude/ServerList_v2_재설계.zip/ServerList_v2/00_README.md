# U4A Workspace ServerList (HTML5)

> **여기부터 읽으세요.** 이 파일 하나로 전체 구조·흐름·"어디를 고치면 되는지"를 파악할 수 있습니다.
> 상세 설계 배경은 `ARCHITECTURE.md`, 기존 UI5 소스 분석은 별도 분석 문서를 참고하세요.

실행 환경: Electron / `nodeIntegration` / `@electron/remote` 직접 사용 / `preload`·`contextBridge` 미사용 / 번들러 없음(CommonJS `require`).

---

## 1. 폴더 한눈에 보기

```
ServerList_v2/
├── ServerList.html      ← 시작 HTML (CSS 6개 + ServerList.js 로드)
├── ServerList.js        ← 진입점 (env/ipc 수신 → bootstrap.init)
│
├── app/        [조립]   앱 조립 부품          (env/bootstrap/lifecycle)
├── core/       [상태]   데이터 단일 출처      (state/store/constants)
├── services/   [도메인] "무엇을 한다"         (레지스트리/XML/저장/버전/실행/사운드…)
├── ipc/        [연동]   Electron·외부 연동     (rendererIpc / netServer)
├── features/   [화면]   기능별 응집(뷰+핸들러) (shell/tree/server-list/server-edit/settings)
├── widgets/    [공통]   재사용 UI             (modal/confirm/toast/busy)
├── i18n/       [문구]   다국어
└── styles/     [스타일] 토큰 기반 CSS
```

> **아이콘·사운드는 별도 폴더를 두지 않는다.** 기존 소스에 이미 갖춰져 있으므로
> 그 경로를 그대로 참조한다(로고 `PATHINFO.WS_LOGO`, 사운드 `APPPATH/sound/sap/*.wav`).
> 접근은 `app/env.js`(PATHINFO/APPPATH) 와 `services/sound.service.js` 에서 처리.

**읽는 규칙 3가지**
1. 모든 폴더에 `README.md` — 그 폴더가 무엇이고 어떤 파일이 있는지 한 줄씩.
2. 모든 `.js` 상단에 **박스 헤더** — `역할 / 시점 / 입출력 / 구대응(옛 함수·라인) / 의존`.
3. 파일명 규칙 — `*.view.js`(그리기) · `*.handler.js`(이벤트) · `*.service.js`(도메인).

---

## 2. 부팅 순서 (그대로 코드와 1:1)

`app/bootstrap.js` 의 `init()` 본문 번호와 동일합니다.

```
ServerList.html → ServerList.js → (IPC 글로벌설정 수신) → app/bootstrap.init()
 1) lifecycle  : 단일 인스턴스 / 창 이벤트 / 작업표시줄
 2) i18n.load  : 다국어 문구 적재            → STATE.WSLANGU
 3) shell      : 헤더 + 2분할 골격 그리기     (features/shell)
 4) systemPort : etc/services 포트 추출
 5) landscape  : 레지스트리→XML→버전체크→가공 → STATE.ServerList / SAPLogon → 트리 렌더
 6) netServer  : 외부 연동 Named Pipe 서버
```

---

## 3. 데이터 흐름 (한 장 요약)

```
레지스트리(SAPLogon 경로)
      │  services/registry
      ▼
SAPUILandscape.xml ──services/landscape──▶ STATE.ServerList (전체 서버)
                    └─services/workspace─▶ STATE.SAPLogon  (좌측 트리)
                                                  │
                          [트리 선택] features/workspace-tree/treeSelect.handler
                                                  ▼
serverInfo_v2.json ──services/serverStore.syncSavedInfo──▶ STATE.SAPLogonItems (우측 표시)
                                                  │ store.set → 구독
                                                  ▼
                               features/server-list/serverTable.view (표/카드)
                                                  │ 더블클릭
                                                  ▼
                               services/login.openLogin (새 BrowserWindow)
```

상태 규칙: **바꿀 땐 `core/store.set(key, value)` → 구독한 뷰가 다시 그림.** 끝.

---

## 4. "이걸 고치고 싶다" → 어디로 가나

| 하고 싶은 것 | 파일 |
|--------------|------|
| 부팅 순서/단계 변경 | `app/bootstrap.js` |
| 화면 골격·헤더·분할 비율 | `features/shell/*`, `styles/layout.css` |
| 좌측 트리 동작 | `features/workspace-tree/*` |
| 우측 표 컬럼·정렬·카드 | `features/server-list/serverTable.view.js`, `styles/components.css`·`responsive.css` |
| Active/Inactive 표시 | `features/server-list/statusBadge.view.js` + `styles/components.css(.ws-status)` |
| 등록/수정/검증 | `features/server-edit/editDialog.view.js` |
| 서버 옵션(useInternal 등) | `features/server-edit/settingsDialog.view.js` |
| 삭제 확인·실행 | `features/server-list/serverAction.handler.js` |
| 저장 파일(JSON) 입출력 | `services/serverStore.service.js` |
| 레지스트리 접근 | `services/registry.service.js` |
| XML 파싱·가공 규칙 | `services/landscape.service.js` |
| SAPGUI 버전 정책 | `services/sapgui.service.js` |
| 로그인 창 생성 옵션 | `services/login.service.js` |
| 색/폰트/간격(테마) | `styles/tokens.css` |
| 다국어 문구 | `i18n/*` |
| 외부 연동(파이프) | `ipc/netServer/*` |

---

## 5. 구현 권장 순서

1. `app/* + core/*` → 빈 화면 + Busy 동작 확인.
2. `services/registry → landscape → workspace` → 콘솔에 데이터 적재 확인.
3. `features/shell + workspace-tree + server-list` → 조회(읽기 전용) 화면 완성.
4. `features/server-edit + services/serverStore + services/login` → 등록·수정·삭제·실행.
5. `features/global-settings + i18n` + 반응형(카드) 마감.
6. `ipc/netServer` → 구 로직 이식(동작 동일).
