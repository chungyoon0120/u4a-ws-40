/**
 * ====================================================================
 *  [서비스] Landscape XML — landscape.service.js
 * --------------------------------------------------------------------
 *  역할   : SAPUILandscape.xml 읽기·파싱·가공 + 서버목록 적재 오케스트레이션
 *  시점   : 부팅 5단계 / XML 파일 변경 감지 시
 *  입출력 : 입력: 레지스트리 경로 / 출력: STATE.ServerList·SAPLogon 갱신
 *  구대응 : fnOnListupSapLogon(L849), fnReadSAPLogonData(L1422), fnSetSAPLogonLandscapeList(L1461), fnSapLogonFileChange(L985)
 *  의존   : core/store, registry/sapgui/workspace.service, app/env(FS,XMLJS)
 * ====================================================================
 */
"use strict";

const store = require("../core/store");

async function listupSapLogon() {
    // TODO(실구현): registry.getSapLogonRegInfo() → readXml() → sapgui.checkVersion()
    //              → buildServerList()(STATE.ServerList) → workspace.buildTree()(STATE.SAPLogon)
    //              → store.set 로 트리/테이블 갱신, FS.watch 재등록.

    /* ===================== 임시 데모 데이터 (실구현 시 이 블록 전체 삭제) =====================
       첨부 화면과 동일한 샘플로 디자인 확인용. 실제로는 위 TODO 흐름으로 채운다. */
    store.set("SAPLogon", {
        Node: [{
            _attributes: { name: "Workspace", uuid: "ROOT" },
            Node: [{ _attributes: { name: "Local", uuid: "LOCAL" } }],
        }],
    });
    store.set("SAPLogonItems", [
        { uuid: "1", name: "1. [UHA] U4A 개발 서버", systemid: "UHA", host: "27.102.205.26",  insno: "00", ISSAVE: true  },
        { uuid: "2", name: "2. [U4A] U4A 운영서버",  systemid: "U4A", host: "27.102.205.25",  insno: "00", ISSAVE: true  },
        { uuid: "3", name: "3. [U4E] U4A 교육서버",  systemid: "U4E", host: "211.218.126.186", insno: "00", ISSAVE: true  },
        { uuid: "4", name: "4. [U41] U4A 2.0 서버",  systemid: "U41", host: "192.168.0.28",   insno: "00", ISSAVE: false },
        { uuid: "5", name: "5. [U42] U4A WS 2.5 서버", systemid: "U42", host: "192.168.0.28", insno: "10", ISSAVE: false },
    ]);
    /* ===================== /임시 데모 데이터 ===================== */
}

function readXml(sFilePath)        { /* TODO */ }
function buildServerList()         { /* TODO */ }
function onFileChange()            { /* TODO: debounce 후 listupSapLogon() */ }
module.exports = { listupSapLogon, readXml, buildServerList, onFileChange };
