/**
 * ====================================================================
 *  [기능:골격] 타이틀바 — titlebar.view.js
 * --------------------------------------------------------------------
 *  역할   : 햄버거(트리 토글) + WS 로고/타이틀 + 최소/최대/닫기
 *  시점   : shell.render() 내부
 *  입출력 : 출력: 헤더 HTML + 버튼 이벤트
 *  구대응 : customHeader(L1731~)
 *  의존   : app/env(CURRWIN), widgets/icons
 * ====================================================================
 */
"use strict";

const { CURRWIN } = require("../../app/env");
const ICON = require("../../widgets/icons");

function markup() {
    return `
      <div class="ws-header">
        <button id="ws-tree-toggle" class="ws-iconbtn" title="메뉴 펼치기/접기">${ICON.menu}</button>
        <div class="ws-brand">
          <span class="ws-brand__logo">WS</span>
          <span>U4A Workspace</span>
        </div>
        <span class="ws-header__spacer"></span>
        <div class="ws-winbtns">
          <button id="ws-win-min"   class="ws-iconbtn" title="Minimize">${ICON.minimize}</button>
          <button id="ws-win-max"   class="ws-iconbtn" title="Maximize">${ICON.maximize}</button>
          <button id="ws-win-close" class="ws-iconbtn ws-iconbtn--close" title="Close">${ICON.close}</button>
        </div>
      </div>`;
}

function wire(onToggleTree) {
    const t = document.getElementById("ws-tree-toggle");
    const min = document.getElementById("ws-win-min");
    const max = document.getElementById("ws-win-max");
    const close = document.getElementById("ws-win-close");
    if (t) t.onclick = () => onToggleTree && onToggleTree();
    if (min) min.onclick = () => CURRWIN.minimize();
    if (max) max.onclick = () => (CURRWIN.isMaximized() ? CURRWIN.unmaximize() : CURRWIN.maximize());
    if (close) close.onclick = () => CURRWIN.close();
}
module.exports = { markup, wire };
