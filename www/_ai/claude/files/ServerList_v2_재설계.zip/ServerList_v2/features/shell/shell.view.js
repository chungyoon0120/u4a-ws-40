/**
 * ====================================================================
 *  [기능:골격] 화면 골격 — shell.view.js
 * --------------------------------------------------------------------
 *  역할   : 헤더+서브헤더+접이식 2분할 생성, 자식뷰 마운트/구독, 트리 토글(데스크톱 접기/모바일 드로어)
 *  시점   : 부팅 3단계
 *  입출력 : 출력: #app DOM, 트리/테이블 mount, store 구독
 *  구대응 : fnOnInitRendering(L1691)
 *  의존   : core/constants·store·state, widgets/icons, ./titlebar.view, ../workspace-tree/tree.view, ../server-list/serverTable.view, ../global-settings/settingsMenu.view
 * ====================================================================
 */
"use strict";

const { DOM } = require("../../core/constants");
const store = require("../../core/store");
const STATE = require("../../core/state");
const ICON = require("../../widgets/icons");
const titlebar = require("./titlebar.view");
const settingsMenu = require("../global-settings/settingsMenu.view");
const tree = require("../workspace-tree/tree.view");
const serverTable = require("../server-list/serverTable.view");

function _toggleTree() {
    const shell = document.querySelector(".ws-shell");
    if (!shell) return;
    const mobile = window.matchMedia("(max-width: 1024px)").matches;
    shell.classList.toggle(mobile ? "is-tree-open" : "is-tree-collapsed");
}

function render() {
    const app = document.getElementById(DOM.APP);
    if (!app) { console.error("[shell] #app 없음"); return; }

    app.innerHTML = `
      <div class="ws-shell">
        ${titlebar.markup()}
        <div class="ws-subheader">
          <span class="ws-subheader__title" data-i18n="ZMSG_WS_COMMON_001/004">U4A Workspace Logon Pad</span>
          <span class="ws-actions">${settingsMenu.markup()}</span>
        </div>
        <div class="ws-body">
          <aside class="ws-pane ws-pane--tree">
            <div class="ws-side-head">${ICON.folder}<span>Workspace</span></div>
            <div id="${DOM.TREE}" style="flex:1;overflow:auto"></div>
          </aside>
          <section class="ws-pane ws-pane--main">
            <div id="${DOM.SERVER_TABLE}" class="ws-table-wrap"></div>
          </section>
          <div class="ws-backdrop" id="ws-backdrop"></div>
        </div>
      </div>`;

    app.hidden = false;

    titlebar.wire(_toggleTree);
    settingsMenu.wire();
    const bd = document.getElementById("ws-backdrop");
    if (bd) bd.onclick = () => document.querySelector(".ws-shell")?.classList.remove("is-tree-open");

    // 초기 렌더 (빈 상태여도 골격은 보임)
    tree.render(STATE.SAPLogon);
    serverTable.render(STATE.SAPLogonItems);

    // 상태 변경 구독
    store.subscribe("SAPLogon", (v) => tree.render(v));
    store.subscribe("SAPLogonItems", (v) => serverTable.render(v));
}

function applyI18n() {
    const i18n = require("../../i18n");
    document.querySelectorAll("[data-i18n]").forEach((el) => {
        const [arbgb, msgnr] = (el.getAttribute("data-i18n") || "").split("/");
        const txt = i18n.t && i18n.t(arbgb, msgnr);
        if (txt) el.textContent = txt;
    });
}
module.exports = { render, applyI18n };
