/**
 * ====================================================================
 *  [기능:목록] 서버 목록 뷰 — serverTable.view.js
 * --------------------------------------------------------------------
 *  역할   : 6컬럼 표(데스크톱)/카드(모바일), 툴바(Edit/Delete), 정렬, 더블클릭 실행, 빈 상태
 *  시점   : shell mount 후 / SAPLogonItems 변경 시
 *  입출력 : 입력: STATE.SAPLogonItems / 출력: #ws-server-table
 *  구대응 : fnGetSAPLogonListTable(L2190)
 *  의존   : core/constants, widgets/icons, ./statusBadge.view, ./serverAction.handler
 * ====================================================================
 */
"use strict";

const { DOM, FIELD } = require("../../core/constants");
const ICON = require("../../widgets/icons");
const statusBadge = require("./statusBadge.view");
const action = require("./serverAction.handler");

const COLS = [
    { key: FIELD.SAVED, label: "STATUS" },
    { key: FIELD.NAME,  label: "SERVER NAME" },
    { key: FIELD.SID,   label: "SID", center: true },
    { key: FIELD.HOST,  label: "HOST(Or IP)" },
    { key: FIELD.SNO,   label: "SNO", center: true },
    { key: "_settings", label: "Settings", center: true },
];

function _cell(it, c) {
    if (c.key === FIELD.SAVED) return statusBadge.html(it[FIELD.SAVED]);
    if (c.key === "_settings") return `<button class="ws-gear" ${it[FIELD.SAVED] ? "" : "disabled"} title="Settings">${ICON.settings}</button>`;
    if (c.key === FIELD.NAME)  return `<span class="ws-cell-name">${it[FIELD.NAME] ?? ""}</span>`;
    if (c.key === FIELD.SID)   return `<span class="ws-chip">${it[FIELD.SID] ?? ""}</span>`;
    if (c.key === FIELD.HOST)  return `<span class="ws-cell-host">${it[FIELD.HOST] ?? ""}</span>`;
    return it[c.key] != null ? String(it[c.key]) : "";
}
function _row(it) {
    return `<tr data-uuid="${it[FIELD.UUID] || ""}">` +
        COLS.map((c) => `<td data-label="${c.label}" class="${c.center ? "ws-col--center" : ""}">${_cell(it, c)}</td>`).join("") +
        `</tr>`;
}

function render(items) {
    const root = document.getElementById(DOM.SERVER_TABLE);
    if (!root) return;
    const list = Array.isArray(items) ? items : [];

    const toolbar = `<div class="ws-table-toolbar">
        <span class="ws-table-toolbar__title">Servers</span>
        <span class="ws-chip">${list.length}</span>
        <span class="ws-table-toolbar__spacer"></span>
        <button class="ws-btn ws-btn--edit"   id="ws-tb-edit">${ICON.edit}<span>Edit</span></button>
        <button class="ws-btn ws-btn--delete" id="ws-tb-delete">${ICON.trash}<span>Delete</span></button>
      </div>`;

    if (!list.length) {
        root.innerHTML = toolbar + `<div class="ws-card"><div class="ws-empty">
            <div class="ws-empty__icon">${ICON.server}</div>
            <div class="ws-empty__title">표시할 서버가 없습니다</div>
            <div class="ws-empty__desc">좌측에서 워크스페이스(폴더)를 선택하세요.</div>
          </div></div>`;
        return;
    }

    const head = `<thead><tr>` +
        COLS.map((c) => `<th class="${c.center ? "ws-col--center" : ""}">${c.label}</th>`).join("") +
        `</tr></thead>`;
    const body = `<tbody>${list.map(_row).join("")}</tbody>`;

    root.innerHTML = toolbar + `<div class="ws-card"><table class="ws-table">${head}${body}</table></div>`;

    root.querySelectorAll("tbody tr[data-uuid]").forEach((tr) => {
        tr.onclick = () => {
            root.querySelectorAll("tbody tr").forEach((x) => x.classList.remove("is-selected"));
            tr.classList.add("is-selected");
        };
        tr.ondblclick = () => action.onActivate(tr.getAttribute("data-uuid"));
    });
    const e = document.getElementById("ws-tb-edit");   if (e) e.onclick = () => action.onEdit();
    const d = document.getElementById("ws-tb-delete"); if (d) d.onclick = () => action.onDelete();
}
function sortBy() {}
function clearSelection() {}
module.exports = { render, sortBy, clearSelection };
