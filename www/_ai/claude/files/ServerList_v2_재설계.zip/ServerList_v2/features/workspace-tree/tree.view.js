/**
 * ====================================================================
 *  [기능:트리] 좌측 트리 뷰 — tree.view.js
 * --------------------------------------------------------------------
 *  역할   : STATE.SAPLogon 재귀 렌더(폴더 아이콘/펼침), 선택 하이라이트
 *  시점   : shell mount 후 / SAPLogon 변경 시
 *  입출력 : 입력: STATE.SAPLogon / 출력: #ws-tree
 *  구대응 : fnGetWorkSpaceTreeTable(L1881)
 *  의존   : core/constants, widgets/icons, ./treeSelect.handler
 * ====================================================================
 */
"use strict";

const { DOM } = require("../../core/constants");
const ICON = require("../../widgets/icons");
const handler = require("./treeSelect.handler");

function _nodes(aNode) {
    if (!Array.isArray(aNode) || !aNode.length) return "";
    return `<ul class="ws-tree__children">` + aNode.map((n) => {
        const a = n._attributes || {};
        const hasKids = Array.isArray(n.Node) && n.Node.length > 0;
        return `<li>
            <div class="ws-tree__node is-open" data-uuid="${a.uuid || ""}">
              <span class="ws-tree__toggle">${hasKids ? ICON.chevron : ""}</span>
              <span class="ws-tree__ico">${ICON.folder}</span>
              <span>${a.name || "(no name)"}</span>
            </div>
            ${hasKids ? _nodes(n.Node) : ""}
          </li>`;
    }).join("") + `</ul>`;
}

function render(treeData) {
    const root = document.getElementById(DOM.TREE);
    if (!root) return;
    const nodes = treeData && treeData.Node ? treeData.Node : [];
    if (!nodes.length) {
        root.innerHTML = `<div class="ws-empty">
            <div class="ws-empty__icon">${ICON.folder}</div>
            <div class="ws-empty__title">워크스페이스 없음</div>
            <div class="ws-empty__desc">서버 목록을 불러오면 여기에 표시됩니다.</div>
          </div>`;
        return;
    }
    root.innerHTML = `<div class="ws-tree">${_nodes(nodes)}</div>`;

    root.querySelectorAll(".ws-tree__node").forEach((el) => {
        el.onclick = (e) => {
            // 펼침 토글 (chevron 영역 클릭)
            const tog = e.target.closest(".ws-tree__toggle");
            if (tog) {
                el.classList.toggle("is-open");
                const sub = el.parentElement.querySelector(":scope > .ws-tree__children");
                if (sub) sub.style.display = el.classList.contains("is-open") ? "" : "none";
                return;
            }
            root.querySelectorAll(".ws-tree__node").forEach((x) => x.classList.remove("is-selected"));
            el.classList.add("is-selected");
            handler.onSelect(el.getAttribute("data-uuid"));
        };
    });
}
function expandToLevel() {}
function select() {}
module.exports = { render, expandToLevel, select };
