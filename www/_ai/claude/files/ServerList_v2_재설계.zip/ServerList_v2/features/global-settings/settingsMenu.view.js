/**
 * ====================================================================
 *  [기능:설정] 설정 메뉴 — settingsMenu.view.js
 * --------------------------------------------------------------------
 *  역할   : 서브헤더 설정 버튼(언어/테마/사운드/About) — 드롭다운은 handler로 확장
 *  시점   : shell mount 후
 *  입출력 : 출력: 버튼 HTML
 *  구대응 : MenuButton/Menu(L1807)
 *  의존   : widgets/icons, ./settings.handler
 * ====================================================================
 */
"use strict";

const ICON = require("../../widgets/icons");
function markup() {
    return `<button id="ws-settings-btn" class="ws-iconbtn" title="Settings">${ICON.settings}</button>`;
}
function wire() {
    // TODO: 클릭 시 .ws-menu 드롭다운(언어/테마/사운드/About) → settings.handler.onSelect(key)
}
module.exports = { markup, wire };
