/**
 * ====================================================================
 *  [UI] 인라인 SVG 아이콘 — icons.js
 * --------------------------------------------------------------------
 *  역할   : sap-icon 대체용 인라인 SVG 문자열 (헤더/툴바/트리 chrome 용)
 *  시점   : 각 뷰가 markup 구성 시
 *  입출력 : 입력: 없음 / 출력: SVG 문자열
 *  구대응 : sap-icon://*
 *  의존   : 없음(문자열 상수)
 * ====================================================================
 */
"use strict";

// stroke 기반, currentColor 상속. class="ws-ico" 로 크기/색 제어.
const S = (p) => `<svg class="ws-ico" viewBox="0 0 24 24" aria-hidden="true">${p}</svg>`;
module.exports = {
    menu:      S(`<path d="M4 7h16M4 12h16M4 17h16"/>`),
    minimize:  S(`<path d="M5 12h14"/>`),
    maximize:  S(`<rect x="5" y="5" width="14" height="14" rx="2"/>`),
    close:     S(`<path d="M6 6l12 12M18 6L6 18"/>`),
    settings:  S(`<circle cx="12" cy="12" r="3"/><path d="M19 12a7 7 0 0 0-.1-1.2l2-1.5-2-3.4-2.3 1a7 7 0 0 0-2-1.2L14 2h-4l-.6 2.7a7 7 0 0 0-2 1.2l-2.3-1-2 3.4 2 1.5A7 7 0 0 0 5 12c0 .4 0 .8.1 1.2l-2 1.5 2 3.4 2.3-1c.6.5 1.3.9 2 1.2L10 22h4l.6-2.7c.7-.3 1.4-.7 2-1.2l2.3 1 2-3.4-2-1.5c.1-.4.1-.8.1-1.2Z"/>`),
    folder:    S(`<path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2Z"/>`),
    server:    S(`<rect x="4" y="4" width="16" height="7" rx="1.5"/><rect x="4" y="13" width="16" height="7" rx="1.5"/><path d="M8 7.5h.01M8 16.5h.01"/>`),
    chevron:   S(`<path d="M9 6l6 6-6 6"/>`),
    edit:      S(`<path d="M4 20h4l10-10-4-4L4 16Z"/><path d="M13.5 6.5l4 4"/>`),
    trash:     S(`<path d="M4 7h16M9 7V5h6v2M6 7l1 13h10l1-13"/>`),
    sortUp:    S(`<path d="M12 19V5M6 11l6-6 6 6"/>`),
    sortDown:  S(`<path d="M12 5v14M6 13l6 6 6-6"/>`),
};
