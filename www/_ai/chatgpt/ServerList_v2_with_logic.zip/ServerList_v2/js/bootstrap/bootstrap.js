(function () {
    "use strict";

    oAPP.bootstrap.initialize = async function () {
        if (oAPP.data.state.isLoading) {
            return;
        }

        oAPP.data.state.isLoading = true;

        try {
            oAPP.ui.layout.render();
            await oAPP.saplogon.initialize();

        } catch (error) {
            oAPP.fn.showError(error);

        } finally {
            oAPP.data.state.isLoading = false;
            oAPP.common.busy.hide();
        }
    };

}());
